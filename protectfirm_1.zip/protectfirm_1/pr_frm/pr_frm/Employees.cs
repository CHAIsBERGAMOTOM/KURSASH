﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace pr_frm
{
    public partial class Employees : Form
    {
        public Employees()
        {
            InitializeComponent();
        }

        private Con_prov _db;
        string id;
        private byte[] imageBytes;

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Employees_Load(object sender, EventArgs e)
        {
            _db = Con_prov.GetInstance();
            SQLiteConnection conn = _db.GetConnection();

            string query = "SELECT ID_Employee, FullName FROM Employees";

            SQLiteCommand cmd = new SQLiteCommand(query, conn);

            SQLiteDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                dataGridView1.Rows.Add(reader["ID_Employee"], reader["FullName"]);
            }
        }



        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                _db = Con_prov.GetInstance();
                SQLiteConnection conn = _db.GetConnection();
                id = dataGridView1.SelectedRows[0].Cells["Column2"].Value.ToString();
                string query = "SELECT FullName, Position, EmploymentDate, Salary, Education, Photo FROM Employees WHERE ID_Employee = @id";
                SQLiteCommand cmd = new SQLiteCommand(query, conn);
                cmd.Parameters.AddWithValue("@id", id);
                SQLiteDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    string fio = reader["FullName"].ToString();
                    string pos = reader["Position"].ToString();
                    string dat = reader["EmploymentDate"].ToString();
                    string sal = reader["Salary"].ToString();
                    string edu = reader["Education"].ToString();

                    textBox1.Text = fio;
                    textBox2.Text = pos;
                    textBox3.Text = dat;
                    textBox4.Text = sal;
                    textBox5.Text = edu;
                    byte[] pht = (byte[])reader["Photo"];
                    MemoryStream ms = new MemoryStream(pht);
                    pictureBox1.Image = System.Drawing.Image.FromStream(ms);
                    pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                    pictureBox1.Refresh();
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string fio = textBox1.Text;
            string pos = textBox2.Text;
            string dat = textBox3.Text;
            string sal = textBox4.Text;
            string edu = textBox5.Text;

            if (string.IsNullOrEmpty(fio) || string.IsNullOrEmpty(pos) || string.IsNullOrEmpty(dat) || string.IsNullOrEmpty(sal) || string.IsNullOrEmpty(edu))
            {
                MessageBox.Show("Заполните все поля.");
            }
            else if (!Regex.IsMatch(fio, "^[а-яА-Я -]+$"))
            {
                MessageBox.Show("Заполните данные ФИО правильно.");
            }
            else if (!Regex.IsMatch(pos, "^[а-яА-Я .-]+$"))
            {
                MessageBox.Show("Заполните данные о специальности правильно.");
            }
            else if (!Regex.IsMatch(dat, "^[0-9 .-]+$"))
            {
                MessageBox.Show("Заполните данные о дате приема на работу правильно.");
            }
            else if (!Regex.IsMatch(sal, "^[0-9 .]+$"))
            {
                MessageBox.Show("Заполните данные о заработной плате правильно.");
            }
            else if (!Regex.IsMatch(edu, "^[а-яА-Я .-]+$"))
            {
                MessageBox.Show("Заполните данные об образовании правильно.");
            }
            else
            {
                using (OpenFileDialog openFileDialog = new OpenFileDialog())
                {  
                    openFileDialog.Filter = "Image files (*.jpg;*.jpeg;*.png)|*.jpg;*.jpeg;*.png";
                    if (openFileDialog.ShowDialog() == DialogResult.OK)
                    {
                        imageBytes = File.ReadAllBytes(openFileDialog.FileName);
                        _db = Con_prov.GetInstance();
                        SQLiteConnection conn = _db.GetConnection();
                        string query = "INSERT INTO Employees (FullName, Position, EmploymentDate, Salary, Education, Photo) VALUES (@fio, @pos, @dat, @sal, @edu, @ph)";
                        SQLiteCommand command = new SQLiteCommand(query, conn);
                        command.Parameters.AddWithValue("@fio", fio);
                        command.Parameters.AddWithValue("@pos", pos);
                        command.Parameters.AddWithValue("@dat", dat);
                        command.Parameters.AddWithValue("@sal", sal);
                        command.Parameters.AddWithValue("@edu", edu);
                        command.Parameters.AddWithValue("@ph", imageBytes);
                        command.ExecuteNonQuery();
                        MessageBox.Show("Запись добавлена в базу!");
                    }
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                _db = Con_prov.GetInstance();
                SQLiteConnection conn = _db.GetConnection();
                string id = dataGridView1.SelectedRows[0].Cells["Column2"].Value.ToString();
                string sql = "DELETE FROM Employees WHERE ID_Employee = @id";
                SQLiteCommand cmd = new SQLiteCommand(sql, conn);
                cmd.Parameters.AddWithValue("@id", id);
                cmd.ExecuteNonQuery();
                dataGridView1.Refresh();
                MessageBox.Show("Запись удалена из базы!");
            }
            else
            {
                MessageBox.Show("Выберите запись для удаления!");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text) || string.IsNullOrEmpty(textBox2.Text) || string.IsNullOrEmpty(textBox3.Text) || string.IsNullOrEmpty(textBox4.Text) || string.IsNullOrEmpty(textBox5.Text))
            {
                MessageBox.Show("Заполните редактируемые поля!");
            }
            else if (!Regex.IsMatch(textBox1.Text, "^[а-яА-Я -]+$"))
            {
                MessageBox.Show("Заполните данные ФИО правильно.");
            }
            else if (!Regex.IsMatch(textBox2.Text, "^[а-яА-Я .-]+$"))
            {
                MessageBox.Show("Заполните данные о специальности правильно.");
            }
            else if (!Regex.IsMatch(textBox3.Text, "^[0-9 .-]+$"))
            {
                MessageBox.Show("Заполните данные о дате приема на работу правильно.");
            }
            else if (!Regex.IsMatch(textBox4.Text, "^[0-9 .]+$"))
            {
                MessageBox.Show("Заполните данные о заработной плате правильно.");
            }
            else if (!Regex.IsMatch(textBox5.Text, "^[а-яА-Я .-]+$"))
            {
                MessageBox.Show("Заполните данные об образовании правильно.");
            }
            else
            {
                _db = Con_prov.GetInstance();
                SQLiteConnection conn = _db.GetConnection();
                string query = "UPDATE Employees SET FullName = @fio, Position = @pos, EmploymentDate = @dat, Salary = @sal, Education = @edu WHERE ID_Employee = @id";
                SQLiteCommand command = new SQLiteCommand(query, conn);
                command.Parameters.AddWithValue("@id", id);
                command.Parameters.Add("@fio", DbType.String).Value = textBox1.Text;
                command.Parameters.Add("@pos", DbType.String).Value = textBox2.Text;
                command.Parameters.Add("@dat", DbType.String).Value = textBox3.Text;
                command.Parameters.Add("@sal", DbType.String).Value = textBox4.Text;
                command.Parameters.Add("@edu", DbType.String).Value = textBox5.Text;
                command.ExecuteNonQuery();
                MessageBox.Show("Запись успешно изменена!");
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
