﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace pr_frm
{
    public partial class Customer : Form
    {
        public Customer()
        {
            InitializeComponent();
        }

        private Con_prov _db;
        string id;

        private void Customer_Load(object sender, EventArgs e)
        {
            _db = Con_prov.GetInstance();
            SQLiteConnection conn = _db.GetConnection();
            string query = "SELECT * FROM Customers";
            SQLiteCommand cmd = new SQLiteCommand(query, conn);
            SQLiteDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                dataGridView1.Rows.Add(reader["ID"], reader["ContactPersonFullName"]);
            }
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                _db = Con_prov.GetInstance();
                SQLiteConnection conn = _db.GetConnection();
                id = dataGridView1.SelectedRows[0].Cells["Column1"].Value.ToString();
                string query = "SELECT Address, AccountNumber, ContactPersonFullName, Phone FROM Customers WHERE ID = @id";
                SQLiteCommand cmd = new SQLiteCommand(query, conn);
                cmd.Parameters.AddWithValue("@id", id);
                SQLiteDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    string add = reader["Address"].ToString();
                    string acn = reader["AccountNumber"].ToString();
                    string cpfn = reader["ContactPersonFullName"].ToString();
                    string phn = reader["Phone"].ToString();

                    textBox1.Text = cpfn;
                    textBox2.Text = add;
                    textBox3.Text = acn;
                    textBox4.Text = phn;
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string one = textBox1.Text;
            string two = textBox2.Text;
            string three = textBox3.Text;
            string four = textBox4.Text;

            if (string.IsNullOrEmpty(one) || string.IsNullOrEmpty(two) || string.IsNullOrEmpty(three) || string.IsNullOrEmpty(four))
            {
                MessageBox.Show("Заполните все поля.");
            }
            else if (!Regex.IsMatch(two, "^[а-яА-Я -]+$"))
            {
                MessageBox.Show("Заполните данные об Адресе правильно.");
            }
            else if (!Regex.IsMatch(three, "^[а-яА-Я0-9 .-]+$"))
            {
                MessageBox.Show("Заполните номер счёта правильно.");
            }
            else if (!Regex.IsMatch(one, "^[а-яА-Я -]+$"))
            {
                MessageBox.Show("Заполните ФИО правильно.");
            }
            else if (!Regex.IsMatch(four, "^[0-9 .()+-]+$"))
            {
                MessageBox.Show("Заполните данные о номере телефона правильно.");
            }
            else
            {
                _db = Con_prov.GetInstance();
                SQLiteConnection conn = _db.GetConnection();
                string query = "INSERT INTO Customers (Address, AccountNumber, ContactPersonFullName, Phone) VALUES (@one, @two, @three, @four)";
                SQLiteCommand command = new SQLiteCommand(query, conn);
                command.Parameters.AddWithValue("@one", two);
                command.Parameters.AddWithValue("@two", three);
                command.Parameters.AddWithValue("@three", one);
                command.Parameters.AddWithValue("@four", four);
                command.ExecuteNonQuery();
                MessageBox.Show("Запись добавлена в базу!");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                _db = Con_prov.GetInstance();
                SQLiteConnection conn = _db.GetConnection();
                string id = dataGridView1.SelectedRows[0].Cells["Column1"].Value.ToString();
                string sql = "DELETE FROM Customers WHERE ID = @id";
                SQLiteCommand cmd = new SQLiteCommand(sql, conn);
                cmd.Parameters.AddWithValue("@id", id);
                cmd.ExecuteNonQuery();
                dataGridView1.Refresh();
                MessageBox.Show("Запись удалена из базы!");
            }
            else
            {
                MessageBox.Show("Выберите запись для удаления!");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text) || string.IsNullOrEmpty(textBox2.Text) || string.IsNullOrEmpty(textBox3.Text) || string.IsNullOrEmpty(textBox4.Text))
            {
                MessageBox.Show("Заполните все поля.");
            }
            else if (!Regex.IsMatch(textBox2.Text, "^[а-яА-Я -]+$"))
            {
                MessageBox.Show("Заполните данные об Адресе правильно.");
            }
            else if (!Regex.IsMatch(textBox3.Text, "^[а-яА-Я0-9 .-]+$"))
            {
                MessageBox.Show("Заполните номер счёта правильно.");
            }
            else if (!Regex.IsMatch(textBox1.Text, "^[а-яА-Я -]+$"))
            {
                MessageBox.Show("Заполните ФИО правильно.");
            }
            else if (!Regex.IsMatch(textBox4.Text, "^[0-9 .()+-]+$"))
            {
                MessageBox.Show("Заполните данные о номере телефона правильно.");
            }
            else
            {
                _db = Con_prov.GetInstance();
                SQLiteConnection conn = _db.GetConnection();
                string query = "UPDATE Customers SET Address = @one, AccountNumber = @two, ContactPersonFullName = @three, Phone = @four WHERE ID = @id";
                SQLiteCommand command = new SQLiteCommand(query, conn);
                command.Parameters.AddWithValue("@id", id);
                command.Parameters.Add("@one", DbType.String).Value = textBox2.Text;
                command.Parameters.Add("@two", DbType.String).Value = textBox3.Text;
                command.Parameters.Add("@three", DbType.String).Value = textBox1.Text;
                command.Parameters.Add("@four", DbType.String).Value = textBox4.Text;
                command.ExecuteNonQuery();
                MessageBox.Show("Запись успешно изменена!");
            }
        }
    }
}
