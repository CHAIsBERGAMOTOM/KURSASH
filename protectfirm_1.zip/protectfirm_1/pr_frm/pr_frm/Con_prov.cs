﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace pr_frm
{
    internal class Con_prov
    {
        private static Con_prov _instance;
        private SQLiteConnection _connection;

        private Con_prov()
        {
            _connection = new SQLiteConnection("Data Source=D:\\protectfirm.db");
            _connection.Open();
        }

        public static Con_prov GetInstance()
        {
            if (_instance == null)
            {
                _instance = new Con_prov();
            }
            return _instance;
        }

        public SQLiteConnection GetConnection()
        {
            return _connection;
        }

        public void CloseConnection()
        {
            if (_connection != null)
            {
                _connection.Close();
            }
        }
    }
}
