﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace pr_frm
{
    public partial class Rep_rec : Form
    {
        public Rep_rec()
        {
            InitializeComponent();
        }

        private Con_prov _db;

        private void Rep_rec_Load(object sender, EventArgs e)
        {
            _db = Con_prov.GetInstance();
            SQLiteConnection conn1 = _db.GetConnection();
            string query3 = "SELECT SUM(s.Cost) AS TotalCost\r\nFROM Orders o\r\nJOIN Services s ON o.ID_Service = s.ID_Service;";
            SQLiteCommand cmd3 = new SQLiteCommand(query3, conn1);
            SQLiteDataReader reader3 = cmd3.ExecuteReader();
            if (reader3.Read())
            {
                string data = reader3["TotalCost"].ToString();
                textBox2.Text = data + " руб.";
            }

            string query4 = "SELECT COUNT(ID) AS cnt FROM Orders o";
            SQLiteCommand cmd4 = new SQLiteCommand(query4, conn1);
            SQLiteDataReader reader4 = cmd4.ExecuteReader();
            if (reader4.Read())
            {
                string data = reader4["cnt"].ToString();
                textBox1.Text = data;
            }
        }
    }
}
