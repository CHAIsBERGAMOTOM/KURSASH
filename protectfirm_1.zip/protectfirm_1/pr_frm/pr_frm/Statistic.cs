﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace pr_frm
{
    public partial class Statistic : Form
    {
        public Statistic()
        {
            InitializeComponent();
        }

        private Con_prov _db;

        private void Statistic_Load(object sender, EventArgs e)
        {
            _db = Con_prov.GetInstance();
            SQLiteConnection conn1 = _db.GetConnection();
            string query1 = "SELECT Employees.FullName FROM Employees";
            SQLiteCommand cmd1 = new SQLiteCommand(query1, conn1);
            SQLiteDataReader reader1 = cmd1.ExecuteReader();
            while (reader1.Read())
            {
                string data = reader1.GetString(0);
                comboBox1.Items.Add(data);
            }

            

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string ide = comboBox1.Text;
            _db = Con_prov.GetInstance();
            SQLiteConnection conn1 = _db.GetConnection();
            string query2 = "SELECT COUNT(*) AS stt FROM Orders WHERE ID_Employee = (SELECT ID_Employee FROM Employees WHERE FullName = @ide)";
            SQLiteCommand cmd2 = new SQLiteCommand(query2, conn1);
            cmd2.Parameters.AddWithValue("@ide", ide);
            SQLiteDataReader reader2 = cmd2.ExecuteReader();
            while (reader2.Read())
            {
                textBox1.Text = reader2["stt"].ToString();
            }
        }
    }
}
