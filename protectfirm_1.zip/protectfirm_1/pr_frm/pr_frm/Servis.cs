﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Runtime.InteropServices.JavaScript.JSType;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace pr_frm
{
    public partial class Servis : Form
    {
        public Servis()
        {
            InitializeComponent();
        }

        private Con_prov _db;
        string id;
        private byte[] imageBytes;

        private void Servis_Load(object sender, EventArgs e)
        {
            _db = Con_prov.GetInstance();
            SQLiteConnection conn = _db.GetConnection();

            string query = "SELECT ID_Service,ServiceName FROM Services";

            SQLiteCommand cmd = new SQLiteCommand(query, conn);

            SQLiteDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                dataGridView1.Rows.Add(reader["ID_Service"], reader["ServiceName"]);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text) || string.IsNullOrEmpty(textBox2.Text))
            {
                MessageBox.Show("Заполните редактируемые поля!");
            }
            else if (!Regex.IsMatch(textBox1.Text, "^[а-яА-Я -]+$"))
            {
                MessageBox.Show("Заполните наименование усуги правильно.");
            }
            else if (!Regex.IsMatch(textBox2.Text, "^[0-9 .]+$"))
            {
                MessageBox.Show("Заполните стоимость услуги правильно.");
            }
            else
            {
                _db = Con_prov.GetInstance();
                SQLiteConnection conn = _db.GetConnection();
                string query = "UPDATE Services SET ServiceName = @sv_nm, Cost = @cst WHERE ID_Service = @id";
                SQLiteCommand command = new SQLiteCommand(query, conn);
                command.Parameters.AddWithValue("@id", id);
                command.Parameters.Add("@sv_nm", DbType.String).Value = textBox1.Text;
                command.Parameters.Add("@cst", DbType.String).Value = textBox2.Text;
                command.ExecuteNonQuery();
                MessageBox.Show("Запись успешно изменена!");
            }
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                _db = Con_prov.GetInstance();
                SQLiteConnection conn = _db.GetConnection();
                id = dataGridView1.SelectedRows[0].Cells["Column1"].Value.ToString();
                string query = "SELECT ID_Service, ServiceName, Cost, photo FROM Services WHERE ID_Service = @id";
                SQLiteCommand cmd = new SQLiteCommand(query, conn);
                cmd.Parameters.AddWithValue("@id", id);
                SQLiteDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    string cal = reader["ServiceName"].ToString();
                    string ph = reader["Cost"].ToString();

                    textBox1.Text = cal;
                    textBox2.Text = ph;

                    byte[] pht = (byte[])reader["photo"];
                    MemoryStream ms = new MemoryStream(pht);
                    pictureBox1.Image = System.Drawing.Image.FromStream(ms);
                    pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                    pictureBox1.Refresh();
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string nm_sv = textBox1.Text;
            double pr = double.Parse(textBox2.Text);
            string trans = pr.ToString();

            if (string.IsNullOrEmpty(nm_sv) || string.IsNullOrEmpty(trans))
            {
                MessageBox.Show("Заполните обязательные поля.");
            }
            else if (!Regex.IsMatch(nm_sv, "^[а-яА-Я -]+$"))
            {
                MessageBox.Show("Заполните наименование усуги правильно.");
            }
            else if (!Regex.IsMatch(trans, "^[0-9 .]+$"))
            {
                MessageBox.Show("Заполните стоимость услуги правильно.");
            }
            else
            {            
                using (OpenFileDialog openFileDialog = new OpenFileDialog())
                {
                    openFileDialog.Filter = "Image files (*.jpg;*.jpeg;*.png)|*.jpg;*.jpeg;*.png";
                    if (openFileDialog.ShowDialog() == DialogResult.OK)
                    {
                        imageBytes = File.ReadAllBytes(openFileDialog.FileName);
                        _db = Con_prov.GetInstance();
                        SQLiteConnection conn = _db.GetConnection();
                        string query = "INSERT INTO Services (ServiceName, Cost, photo) VALUES (@nm_sv, @pr, @ph)";
                        SQLiteCommand command = new SQLiteCommand(query, conn);
                        command.Parameters.AddWithValue("@nm_sv", nm_sv);
                        command.Parameters.AddWithValue("@pr", pr);
                        command.Parameters.AddWithValue("@ph", imageBytes);
                        command.ExecuteNonQuery();
                        MessageBox.Show("Запись добавлена в базу!");
                    }
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                _db = Con_prov.GetInstance();
                SQLiteConnection conn = _db.GetConnection();
                string id = dataGridView1.SelectedRows[0].Cells["Column1"].Value.ToString();
                string sql = "DELETE FROM Services WHERE ID_Service = @id";
                SQLiteCommand cmd = new SQLiteCommand(sql, conn);
                cmd.Parameters.AddWithValue("@id", id);
                cmd.ExecuteNonQuery();
                dataGridView1.Refresh();
                MessageBox.Show("Запись удалена из базы!");
            }
            else
            {
                MessageBox.Show("Выберите запись для удаления!");
            }
        }
    }
}
