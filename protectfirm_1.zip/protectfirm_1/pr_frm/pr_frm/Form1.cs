using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace pr_frm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private Con_prov _db;
        string id;
        private byte[] imageBytes;

        private void ����������ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Employees employees = new Employees();
            employees.ShowDialog(this);
        }

        private void �������ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Customer customer = new Customer();
            customer.ShowDialog(this);
        }

        private void ������ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Servis servis = new Servis();
            servis.ShowDialog(this);
        }

        private void update_table()
        {
            comboBox1.Items.Clear();
            comboBox2.Items.Clear();
            comboBox3.Items.Clear();
            dataGridView1.Rows.Clear();
            _db = Con_prov.GetInstance();
            SQLiteConnection conn = _db.GetConnection();
            string query = "SELECT Orders.ID, Employees.FullName AS Employee_name,Customers.ContactPersonFullName AS Customer_name, Services.ServiceName AS Service_name, Orders.Order_Date, Orders.Status_order\r\nFROM Orders \r\nINNER JOIN Employees ON Orders.ID_Employee = Employees.ID_Employee\r\nINNER JOIN Customers ON Orders.ID_Customer = Customers.ID\r\nINNER JOIN Services ON Orders.ID_Service = Services.ID_Service;";
            SQLiteCommand cmd = new SQLiteCommand(query, conn);
            SQLiteDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                dataGridView1.Rows.Add(reader["ID"], reader["Employee_name"], reader["Customer_name"], reader["Service_name"], reader["Order_Date"], reader["Status_order"]);
            }

            _db = Con_prov.GetInstance();
            SQLiteConnection conn1 = _db.GetConnection();
            string query1 = "SELECT DISTINCT Customers.ContactPersonFullName FROM Customers";
            SQLiteCommand cmd1 = new SQLiteCommand(query1, conn1);
            SQLiteDataReader reader1 = cmd1.ExecuteReader();
            while (reader1.Read())
            {
                string data = reader1.GetString(0);
                comboBox2.Items.Add(data);
            }

            _db = Con_prov.GetInstance();
            SQLiteConnection conn3 = _db.GetConnection();
            string query3 = "SELECT DISTINCT Employees.FullName FROM Employees";
            SQLiteCommand cmd3 = new SQLiteCommand(query3, conn3);
            SQLiteDataReader reader3 = cmd3.ExecuteReader();
            while (reader3.Read())
            {
                string data = reader3.GetString(0);
                comboBox1.Items.Add(data);
            }

            _db = Con_prov.GetInstance();
            SQLiteConnection conn2 = _db.GetConnection();
            string query2 = "SELECT DISTINCT Services.ServiceName FROM Services";
            SQLiteCommand cmd2 = new SQLiteCommand(query2, conn2);
            SQLiteDataReader reader2 = cmd2.ExecuteReader();
            while (reader2.Read())
            {
                string data = reader2.GetString(0);
                comboBox3.Items.Add(data);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            update_table();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("���������� ���������� ���� ��������� �� ������, �������� � �������� ��������� � �����.", "�������������", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
            if (result == DialogResult.OK)
            {
                using (OpenFileDialog openFileDialog = new OpenFileDialog())
                {
                    openFileDialog.Filter = "Image files (*.jpg;*.jpeg;*.png)|*.jpg;*.jpeg;*.png";
                    if (openFileDialog.ShowDialog() == DialogResult.OK)
                    {
                        imageBytes = File.ReadAllBytes(openFileDialog.FileName);
                        _db = Con_prov.GetInstance();
                        SQLiteConnection conn = _db.GetConnection();
                        id = dataGridView1.SelectedRows[0].Cells["Column1"].Value.ToString();
                        string query = "UPDATE Orders SET Redactorder_photo = @Photo WHERE ID = @id";
                        SQLiteCommand command = new SQLiteCommand(query, conn);
                        command.Parameters.AddWithValue("@Photo", imageBytes);
                        command.Parameters.AddWithValue("@id", id);
                        command.ExecuteNonQuery();
                        MessageBox.Show("������ ������� �������!");
                        update_table();
                    }
                }
            }
            else
            {
                MessageBox.Show("��������� ��������");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

            string fio_e = comboBox1.Text;
            string fio_c = comboBox2.Text;
            string ser = comboBox3.Text;
            string dat = textBox4.Text;
            string stt = textBox5.Text;

            if (string.IsNullOrEmpty(fio_e) || string.IsNullOrEmpty(fio_c) || string.IsNullOrEmpty(ser) || string.IsNullOrEmpty(dat))
            {
                MessageBox.Show("��������� ��� ������������ ����!");
            }
            else if (!Regex.IsMatch(dat, "\\d\\d\\d\\d-\\d\\d-\\d\\d"))
            {
                MessageBox.Show("��������� ���� ������ ���������!");
            }
            else if (!Regex.IsMatch(stt, "^[�-��-�a-zA-Z .-]+$"))
            {
                MessageBox.Show("��������� ������ ������ ���������!");
            }
            else
            {
                _db = Con_prov.GetInstance();
                SQLiteConnection conn = _db.GetConnection();
                string query = "INSERT INTO Orders (ID_Employee, ID_Customer, ID_Service, Order_Date, Status_order) VALUES ((SELECT ID_Employee FROM Employees WHERE FullName = @fio_e),(SELECT ID FROM Customers WHERE ContactPersonFullName = @fio_c),(SELECT ID_Service FROM Services WHERE ServiceName = @ser), @dat, @stt)";

                SQLiteCommand command = new SQLiteCommand(query, conn);
                command.Parameters.AddWithValue("@fio_e", fio_e);
                command.Parameters.AddWithValue("@fio_c", fio_c);
                command.Parameters.AddWithValue("@ser", ser);
                command.Parameters.AddWithValue("@dat", dat);
                command.Parameters.AddWithValue("@stt", stt);

                command.ExecuteNonQuery();
                MessageBox.Show("������ ��������� � ����!");
                update_table();
            }

        }

        private void �������������ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Rep_rec rep_rec = new Rep_rec();
            rep_rec.ShowDialog(this);
        }

        private void ���������������������ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Statistic st = new Statistic();
            st.ShowDialog(this);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string stt = textBox5.Text;
            _db = Con_prov.GetInstance();
            SQLiteConnection conn = _db.GetConnection();
            string query = "UPDATE Orders SET Status_order = @stt WHERE ID = @id";
            SQLiteCommand command = new SQLiteCommand(query, conn);
            command.Parameters.AddWithValue("@id", id);
            command.Parameters.AddWithValue("@stt", stt);
            command.ExecuteNonQuery();
            MessageBox.Show("������ ������� �������!");
            update_table();
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                _db = Con_prov.GetInstance();
                SQLiteConnection conn = _db.GetConnection();
                id = dataGridView1.SelectedRows[0].Cells["Column1"].Value.ToString();
                string query = "SELECT Orders.ID, Employees.FullName AS Employee_name,Customers.ContactPersonFullName AS Customer_name, Services.ServiceName AS Service_name, Orders.Order_Date, Orders.Status_order\r\nFROM Orders \r\nINNER JOIN Employees ON Orders.ID_Employee = Employees.ID_Employee\r\nINNER JOIN Customers ON Orders.ID_Customer = Customers.ID\r\nINNER JOIN Services ON Orders.ID_Service = Services.ID_Service WHERE Orders.ID = @id;";
                SQLiteCommand cmd = new SQLiteCommand(query, conn);
                cmd.Parameters.AddWithValue("@id", id);
                SQLiteDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    comboBox1.Text = reader["Employee_name"].ToString();
                    comboBox2.Text = reader["Customer_name"].ToString();
                    comboBox3.Text = reader["Service_name"].ToString();
                    textBox4.Text = reader["Order_Date"].ToString();
                    textBox5.Text = reader["Status_order"].ToString();

                }
            }
        }
    }
}
